library(testthat)
library(Blofeld)

test_check("Blofeld")
