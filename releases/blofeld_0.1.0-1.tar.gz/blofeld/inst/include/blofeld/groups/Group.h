#ifndef BLOFELD_GROUP_H
#define BLOFELD_GROUP_H

namespace blofeld
{

  template <auto s_cts>
  class Group
  {
  };

} // blofeld

#endif // BLOFELD_GROUP_H
