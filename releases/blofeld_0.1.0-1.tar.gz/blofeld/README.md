# blofeld
R package and repository for the Blofeld modelling framework
