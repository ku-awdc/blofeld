loadModule("blofeld_module", TRUE)

.onAttach <- function(lib, pkg)
{
  ## TODO: note API version
  # packageStartupMessage("Hello!")

}
